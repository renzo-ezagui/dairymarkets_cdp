<?php
get_header();
get_template_part( 'parts/error','404' );
get_footer();
?>