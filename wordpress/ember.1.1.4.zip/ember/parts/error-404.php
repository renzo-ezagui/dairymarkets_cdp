<div class="main_content content row content_squeeze">
    <div class="col-xs-12">
        <h2 class="page_title text-center"><?php _e('404', 'ember'); ?><br /><?php _e('The content you are looking for is not available.', 'ember'); ?></h2>
    </div>
</div>