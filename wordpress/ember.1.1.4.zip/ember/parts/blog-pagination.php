<div class="row blog_pagination">
    <div class="col-sm-6 next_posts_link">
    <?php next_posts_link(__('... Older Posts', 'ember')) ?>
    </div>
    <div class="col-sm-6 previous_posts_link text-right">
    <?php previous_posts_link(__('Newer Posts ...', 'ember')) ?>
    </div>
</div>
