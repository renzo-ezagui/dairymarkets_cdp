/** Fire up jQuery - let's dance! */
jQuery(document).ready(function($) {
	$("a.tooltip").tooltip();
});
